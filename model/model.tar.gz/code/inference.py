import whisper

def process_data(data):
    """
    A function that processes the given data and extracts the required information.

    Parameters:
        - data (dict): A dictionary containing the input data.

    Returns:
        - result (dict): A dictionary containing the processed data.
    """
    result = {}
    result['text'] = data['text']
    result['segments'] = []
    for segment in data['segments']:
        temp_dict = {}
        temp_dict['id'] = segment['id']
        temp_dict['seek'] = segment['seek']
        temp_dict['start'] = segment['start']
        temp_dict['end'] = segment['end']
        temp_dict['text'] = segment['text']
        result['segments'].append(temp_dict)
    result['language'] = data['language']
    return result

def model_fn(model_dir):
    model = whisper.load_model("large-v2")
    return model


def predict_fn(audio_bytes, model):
    audio_file = "tmp.mp3"
    
    with open(audio_file, "wb") as binary_file:
        binary_file.write(audio_bytes['inputs'])
        
    result = model.transcribe(
        audio_file,
        word_timestamps=True
    )
    
    response = process_data(result)
    
    return response
